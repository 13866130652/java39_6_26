/**
 * Created by er on 2017/6/26.
 */
function reduc1(){
    var jian = parseInt(document.getElementById("num1").value);
    jian = jian - 1;
    if(jian <= 0) {
        jian = 0;
    }
    document.getElementById("num1").value = jian;
    document.getElementById("price3").innerHTML = (jian * parseFloat(document.getElementById("dan1").value)).toFixed(2);
}

function plu1(){
    var jian = parseInt(document.getElementById("num1").value);
    jian = jian + 1;
    document.getElementById("num1").value = jian;
    document.getElementById("price3").innerHTML = (jian * parseFloat(document.getElementById("dan1").value)).toFixed(2);
}

function reduc2() {
    var jian = parseInt(document.getElementById("num2").value);
    jian = jian - 1;
    if(jian <= 0) {
        jian = 0;
    }
    document.getElementById("num2").value = jian;
    document.getElementById("price4").innerHTML = (jian * parseFloat(document.getElementById("dan2").value)).toFixed(2);

}
function plu2() {
    var jian = parseInt(document.getElementById("num2").value);
    jian = jian + 1;
    document.getElementById("num2").value = jian;
    document.getElementById("price4").innerHTML = (jian * parseFloat(document.getElementById("dan2").value)).toFixed(2);
}

function sum() {
    document.getElementById("sumPrice").innerHTML = (parseFloat(document.getElementById("price3").innerHTML) + parseFloat(document.getElementById("price4").innerHTML)).toFixed(2);
    var p=document.getElementById("ll");
    p.style.border="1px solid red";
    p.innerHTML="您本次购买的商品信息如下：<br/>白岩松：白说：￥"+document.getElementById("price3").innerText+
        "<br/>岛上书店：￥"+document.getElementById("price4").innerText+"<br/>商品共计：￥"+
        (document.getElementById("sumPrice").innerHTML);
}