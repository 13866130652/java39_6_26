var num = parseInt(document.getElementById("number").innerHTML);
var danjia = parseFloat(document.getElementById("danjia").innerHTML);
var zongjia = parseFloat(document.getElementById("zongjia").innerHTML);
var num1 = parseInt(document.getElementById("number1").innerHTML);
var danjia1 = parseFloat(document.getElementById("danjia1").innerHTML);
var zongjia1 = parseFloat(document.getElementById("zongjia1").innerHTML);

function downNum() {
	if (num > 0) {
		num--;
	} else {
		num = 0;
	}
	document.getElementById("number").innerHTML = num;
	document.getElementById("zongjia").innerHTML = (num * danjia).toFixed(2);
}

function addNum() {
	num++;
	document.getElementById("number").innerHTML = num;
	document.getElementById("zongjia").innerHTML = (num * danjia).toFixed(2);
}

function downNum1() {
	if (num1 > 0) {
		num1--;
	} else {
		num1 = 0;
	}
	document.getElementById("number1").innerHTML = num1;
	document.getElementById("zongjia1").innerHTML = (num1 * danjia1).toFixed(2);
}

function addNum1() {
	num1++;
	document.getElementById("number1").innerHTML = num1;
	document.getElementById("zongjia1").innerHTML = (num1 * danjia1).toFixed(2);
}

function sum() {
	var zongji = parseFloat(document.getElementById("zongji").innerHTML);
	document.getElementById("zongji").innerHTML = ((num * danjia) + (num1 * danjia1)).toFixed(2);
	var p = document.getElementById("p");
	p.style.border = "1px solid red";
	document.getElementById("zongji").nextElementSibling.innerHTML = "您本次购买的商品信息如下:<br />" + "白岩松:白说:￥" + (num * danjia).toFixed(2) + "<br/>岛上书店:￥" + (num1 * danjia1).toFixed(2) + "<br/>商品总计:￥" + ((num * danjia) + (num1 * danjia1)).toFixed(2);
}