var arrImg = ['../img/2.jpg', '../img/3.jpg', '../img/4.jpg'];
var i = 0;

function changeImg() {
	if (i == 3) {
		i = 0;
	}
	var imge = document.getElementById("img");
	imge.src = arrImg[i];
	changeTagBackground();
	i++;
}

var num = 0;

function lun() {
	num = setInterval("changeImg()", 1000);
}
lun();

function stopLun() {
	clearInterval(num);
}

function changeTagBackground() {
	var imge = document.getElementById("img");
	var arrA = document.getElementsByTagName("a");
	for (var j = 0; j < arrA.length; j++) {
		if (i == j) {
			arrA[j].style.backgroundColor = "gray";
		} else {
			arrA[j].style.backgroundColor = "gainsboro";
		}
	}
}