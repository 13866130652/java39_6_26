var p1 = document.getElementById("p1");

function showTimes() {
	var date = new Date();
	var year = date.getFullYear() + "年";
	var month = date.getMonth() + 1 + "月";
	var day = date.getDay() + "日";
	var hour = date.getHours();
	if (hour > 12) {
		hour = (hour - 12) + "点"
	}
	var minutes = date.getMinutes() + "分";
	var second = date.getSeconds() + "s";

	p1.innerHTML = "当前年：" + year + "<br/>当前月：" + month + "<br/>当前日：" + day + "<br/>当前12期时：" + hour + "<br/>当前分：" + minutes + "<br/>当前秒：" + second;
}
var num = 0;

function dongtai() {
	num = setInterval("showTimes()", 1000);
}