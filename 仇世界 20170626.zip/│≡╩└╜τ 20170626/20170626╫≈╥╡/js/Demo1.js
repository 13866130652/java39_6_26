/**
 * Created by Administrator on 2017/6/26 0026.
 */
var i=0;
//获得对应的a标记，同时设置其背景颜色
function getA() {
    var arr=document.getElementsByTagName("a");
    for (var j = 0; j < arr.length; j++) {
        if (i == j) {
            arr[j].style.backgroundColor = "blue";
        } else {
            arr[j].style.backgroundColor = "grey";
        }
    }
}
//实现图片的轮播效果
function change() {
    if(i==4){
        i=0;
    }
    var img=document.getElementById("image");
    var arr=["../images/ww1.jpg","../images/ww2.jpg","../images/ww3.jpg","../images/ww4.jpg"]
    img.src=arr[i];
    getA();
    i++;
}
var num=0;
//循环调用某函数执行循环操作
function ch() {
    num=setInterval("change()",1500);
}
ch();
//当鼠标移入到某a标记时，显示对应的图片，同时改变其背景颜色
function stop(n) {
    clearInterval(num);
    var img = document.getElementById("image");
    var ar=["../images/ww1.jpg","../images/ww2.jpg","../images/ww3.jpg","../images/ww4.jpg"]
    img.src=ar[n-1];
    var arr = document.getElementsByTagName("a");
    for (var j = 0; j < arr.length; j++) {
        if (n == j+1) {
            arr[j].style.backgroundColor = "blue";
        } else {
            arr[j].style.backgroundColor = "grey";
        }
    }
}