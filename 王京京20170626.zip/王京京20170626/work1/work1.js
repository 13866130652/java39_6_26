/**
 * Created by WangJingJing on 2017/6/26.
 */
var i=1;
function getFlag(){
    var gather=document.getElementsByTagName("a");
    for(var j=0;j<gather.length;j++){
        if(i==j+1){
            gather[j].style.backgroundColor="red";
        }else{
            gather[j].style.backgroundColor="grey";
        }
    }
}
//ͼƬ��������
function change(){
    if(i==5){
        i=1;
    }
    var img=document.getElementById("image");
    img.src=i+".jpg";
    getFlag();
    i++;
}
//���ö�ʱ��������������ͼƬ
var num=0;
function changeImage(){
    num=setInterval("change()",1000);
}
function stop(n){
    clearInterval(num);
    var img=document.getElementById("image");
    img.src=n+".jpg";
    var gather=document.getElementsByTagName("a");
    for(var j=0;j<gather.length;j++){
        if(n==j+1){
            gather[j].style.backgroundColor="red";
        }else{
            gather[j].style.backgroundColor="grey";
        }
    }
}
changeImage();