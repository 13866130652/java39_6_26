/**
 * Created by WangJingJing on 2017/6/26.
 */
function showTime(){
    var time;
    var today=new Date();
    var year=today.getFullYear();
    var month=today.getMonth()+1;
    var day=today.getDate();
    var hour=today.getHours();
    var minute=today.getMinutes();
    var second=today.getSeconds();
    if(hour>12){
        hour=hour-12;
        time=hour+":"+minute+":"+second+"     PM";
    }else{
        time=hour+":"+minute+":"+second+"     AM";
    }
    var day=today.getDay();
    document.getElementById("time").innerHTML=year+"��"+month+"��"+day+"��     "+time+"     ����"+day;
}
setInterval("showTime()",1000)