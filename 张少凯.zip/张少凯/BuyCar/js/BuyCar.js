/**
 * Created by zshock on 2017/6/25.
 */
var count = 0;

function upNum(){
    var allM = parseFloat(document.getElementById("allMoney").textContent);
    var price = document.getElementById("per1").textContent;
    var all = parseFloat(document.getElementById("allPrice").textContent);
    var num = document.getElementById("num");
    count = parseInt(num.value);
    num.value=++count;
    all = (parseFloat(price)*parseInt(num.value)).toFixed(2);
    allM = allM+parseFloat(price);
    document.getElementById("allMoney").innerHTML = allM.toFixed(2);
    document.getElementById("allPrice").innerHTML= all;

}
function upNum2(){
    var allM = parseFloat(document.getElementById("allMoney").textContent);
    var price = document.getElementById("per2").textContent;
    var all = parseFloat(document.getElementById("allPrice2").textContent);
    var num = document.getElementById("num2");
    count = parseInt(num.value);
    num.value=++count;
    all = parseFloat(price)*parseInt(num.value).toFixed(2);
    allM += parseFloat(price);
    document.getElementById("allMoney").innerHTML = allM.toFixed(2);
    document.getElementById("allPrice2").innerHTML= all.toFixed(2);


}
function lowNum(){
    var allM = parseFloat(document.getElementById("allMoney").textContent);
    var all = parseFloat(document.getElementById("allPrice").textContent);
    var price = parseFloat(document.getElementById("per1").textContent);
    var num = document.getElementById("num");
    count = parseInt(num.value);
    if(count<1){
        num.value = 0;
    }else{
        num.value=--count;
        all = parseFloat(price)*parseInt(num.value).toFixed(2);
        allM -= parseFloat(price);
        document.getElementById("allMoney").innerHTML = allM.toFixed(2);
        document.getElementById("allPrice").innerHTML= all.toFixed(2);
    }

}
function lowNum2(){
    var allM = parseFloat(document.getElementById("allMoney").textContent);
    var all = parseFloat(document.getElementById("allPrice2").textContent);
    var price = parseFloat(document.getElementById("per2").textContent);
    var num = document.getElementById("num2");
    count = parseInt(num.value);
    if(count<1){
        num.value = 0;
    }else{
        num.value=--count;
        all = parseFloat(price)*parseInt(num.value).toFixed(2);
        allM -= parseFloat(price);
        document.getElementById("allMoney").innerHTML = allM.toFixed(2);
        document.getElementById("allPrice2").innerHTML= all.toFixed(2);
    }

}
function getMoney(){
    var texta = document.getElementById("productP");
    var str = "";
    var ul1 = document.getElementById("i_2").children;
    var li1 = ul1[0].children;
    var span1 = li1[2].children;
    var price_1 = span1[1].innerHTML;
    var ul2 = document.getElementById("i_1").children;
    var li2 = ul2[0].children;
    var span2 = li2[2].children;
    var price_2 = span2[1].innerHTML;
    var sumPrice =parseFloat(price_1)+parseFloat(price_2);
    str = "�����ι������Ʒ����:\n1.�����ɣ���˵ "+price_2+"Ԫ\n2.������� "+price_1+"Ԫ\n�ϼƣ�"+sumPrice+"Ԫ";
    texta.innerText=str;
}
