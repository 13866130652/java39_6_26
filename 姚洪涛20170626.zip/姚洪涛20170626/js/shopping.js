function reduc1(){
	var jian = parseInt(document.getElementById("num1").value);
	jian = jian - 1;
	if(jian <= 0) {
		jian = 0;
	}
	document.getElementById("num1").value = jian;
	document.getElementById("price3").innerHTML = (jian * parseFloat(document.getElementById("dan1").value)).toFixed(2);
}

function plu1(){
	var jian = parseInt(document.getElementById("num1").value);
	jian = jian + 1;
	document.getElementById("num1").value = jian;
	document.getElementById("price3").innerHTML = (jian * parseFloat(document.getElementById("dan1").value)).toFixed(2);
}

function reduc2() {
	var jian = parseInt(document.getElementById("num2").value);
	jian = jian - 1;
	if(jian <= 0) {
		jian = 0;
	}
	document.getElementById("num2").value = jian;
	document.getElementById("price4").innerHTML = (jian * parseFloat(document.getElementById("dan2").value)).toFixed(2);

}
function plu2() {
	var jian = parseInt(document.getElementById("num2").value);
	jian = jian + 1;
	document.getElementById("num2").value = jian;
	document.getElementById("price4").innerHTML = (jian * parseFloat(document.getElementById("dan2").value)).toFixed(2);
}

function sum() {
	document.getElementById("sumPrice").innerHTML = (parseFloat(document.getElementById("price3").innerHTML) + parseFloat(document.getElementById("price4").innerHTML)).toFixed(2);
	document.getElementById("spa").parentElement.nextElementSibling.innerHTML="你本次的购物信息:<br/>"+"白岩松:白说"+"&nbsp;¥"+document.getElementsByTagName("span")[1].innerHTML+"<br/>岛上书店:&nbsp;¥"+document.getElementById("price4").innerHTML+"<br/>共计:&nbsp;¥"+document.getElementById("sumPrice").innerHTML;
}