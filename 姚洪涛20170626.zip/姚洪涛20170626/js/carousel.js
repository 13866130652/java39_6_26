//图片的序号
var i = 1;
//获得对应的a标记，同时设置其背景颜色
function getA() {
	var arr = document.getElementsByTagName("a");
	for(var j = 0; j < arr.length; j++) {
		if(i == j + 1) {
			arr[j].style.backgroundColor = "blue";
		} else {
			arr[j].style.backgroundColor = "grey";
		}
	}
}

//实现图片的轮播效果
function change() {
	if(i == 5) {
		i = 1;
	}
	var img = document.getElementById("image");
	img.src = "../images/" + i + ".jpg";
	getA();
	i++;
}

//循环调用某函数执行循环操作
var num = 0;

function ch() {
	num = setInterval("change()", 1000);
}
ch();

//当鼠标移入到某a标记时，显示对应的图片，同时改变其背景颜色
function stop(n) {
	clearInterval(num);
	var img = document.getElementById("image");
	img.src = "../images/" + n + ".jpg";
	var arr = document.getElementsByTagName("a");
	for(var j = 0; j < arr.length; j++) {
		if(n == j + 1) {
			arr[j].style.backgroundColor = "blue";
		} else {
			arr[j].style.backgroundColor = "grey";
		}
	}
}

function zuo() {
	clearInterval(num);
	i--;
	if(i <= 1) {
		i = 1;
	}
	var arr = document.getElementsByTagName("a");
	for(var j = 0; j < arr.length; j++) {
		if(i == j + 1) {
			arr[j].style.backgroundColor = "blue";
		} else {
			arr[j].style.backgroundColor = "grey";
		}
	}

	document.getElementById("image").src = "../images/" + (i) + ".jpg";
}

function you() {
	clearInterval(num);
	i++;
	if(i >= 4) {
		i = 4;
	}
	var arr = document.getElementsByTagName("a");
	for(var j = 0; j < arr.length; j++) {
		if(i == j + 1) {
			arr[j].style.backgroundColor = "blue";
		} else {
			arr[j].style.backgroundColor = "grey";
		}
	}
	document.getElementById("image").src = "../images/" + (i)+ ".jpg";
}