function sho() {
	var s;
	var date = new Date();
	document.getElementById("s1").innerHTML = date;
	var a= date.getFullYear(); //2017
		document.getElementById("s2").innerHTML=a;
	//date.getYear();//117,1900年算第一年
	var b= date.getMonth()+1;
	document.getElementById("s3").innerHTML =b;
	var c= date.getDate();
	document.getElementById("s4").innerHTML =c;
	var d=date.getHours();
	document.getElementById("s5").innerHTML = d;
	var e=date.getMinutes();
	document.getElementById("s6").innerHTML = e;
	var f= date.getSeconds();
	document.getElementById("s7").innerHTML =f;
	var g= date.getDay();
	document.getElementById("s8").innerHTML =g;
	document.getElementById("s9").innerHTML = date.getTime();
	if(d>12){
		s="PM&nbsp;"+(d-12);
	}else {
		s="AM&nbsp;"+(d);
	}
	if(g==0){
		g="日";
	}
	document.getElementById("s10").innerHTML =a+"年&nbsp;"+b+"月&nbsp;"+c+"日&nbsp;"+s+"时&nbsp;"+e+"分&nbsp;"+f+"秒&nbsp;";
	
}
setInterval(sho,1000);
