function getEl(id) {
	return document.getElementById(id);
}

function clockTime() {
	var today = new Date();
	if(today.getHours() >= 12) {
		getEl("p1").innerHTML = today.getFullYear() + "年" + (today.getMonth() + 1) + "月" +
			today.getDate() + "日" + "PM" + (today.getHours() - 12) + "时" + today.getMinutes() + "分" + today.getSeconds() + "秒";
	} else {
		getEl("p1").innerHTML = today.getFullYear() + "年" + (today.getMonth() + 1) + "月" +
			today.getDate() + "日" + "AM" + today.getHours() + "时" + today.getMinutes() + "分" + today.getSeconds() + "秒";
	}
	var weekday = new Array(7);
	weekday[0] = "周日";
	weekday[1] = "周一";
	weekday[2] = "周二";
	weekday[3] = "周三";
	weekday[4] = "周四";
	weekday[5] = "周五";
	weekday[6] = "周六";
	var x = document.getElementById("p2");
	x.innerHTML = "今天是：" + weekday[today.getDay()];
}
var num = setInterval("clockTime()", 1000);