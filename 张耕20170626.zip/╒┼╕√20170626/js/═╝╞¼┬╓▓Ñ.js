var i = 1;

function getA() {
	var arr = document.getElementsByTagName("a");
	for(var j = 0; j < arr.length; j++) {
		if(i == j + 1) {
			arr[j].style.backgroundColor = "deepskyblue";
		} else {
			arr[j].style.backgroundColor = "grey";
		}
	}
}

function change() {
	if(i == 5) {
		i = 1;
	}
	var img = document.getElementById("image");
	img.src = "../img/" + i + ".jpg";
	getA();
	i++;
}

var num = 0;

function ch() {
	num = setInterval("change()", 1000);
}
ch();

function stop(n) {
	clearInterval(num);
	var img = document.getElementById("image");
	img.src = "../img/" + n + ".jpg";
	var arr = document.getElementsByTagName("a");
	for(var j = 0; j < arr.length; j++) {
		if(n == j + 1) {
			arr[j].style.backgroundColor = "deepskyblue";
		} else {
			arr[j].style.backgroundColor = "grey";
		}
	}
}